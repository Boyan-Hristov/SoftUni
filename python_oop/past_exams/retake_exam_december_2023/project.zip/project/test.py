# result = []
# matrix = [[1, 2, 3], [], [4, 5, 6, 2], [7, 8]]
# for el in matrix:
#     result.extend(el)
# result = set(result)
# print(result)

peaks = ["MountEverest", "K2"]
print(sorted(", ".join(peaks)))
