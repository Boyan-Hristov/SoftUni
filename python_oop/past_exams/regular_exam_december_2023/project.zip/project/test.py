a = 1
print(round(a))
b = ""
print(bool(b))
